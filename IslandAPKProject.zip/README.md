
# Island APK Project Skeleton

Open in Android Studio and complete Gradle configuration.
Includes:
- AndroidManifest.xml
- MainActivity.kt
- IslandService.kt
- BootReceiver.kt
- island_layout.xml
